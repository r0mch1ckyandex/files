﻿using System;

class Calculator
{
    static void Main(string[] args)
    {
        bool continueCalculating = true;

        while (continueCalculating)
        {
            Console.WriteLine("\n=== Multifunctional Calculator ===");
            Console.WriteLine("1. Basic Arithmetic");
            Console.WriteLine("2. Power");
            Console.WriteLine("3. Square Root");
            Console.WriteLine("4. Percentage");
            Console.WriteLine("5. Area Calculator");
            Console.WriteLine("6. Exit");
            Console.Write("\nChoose an operation (1-6): ");

            string choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    PerformBasicArithmetic();
                    break;
                case "2":
                    CalculatePower();
                    break;
                case "3":
                    CalculateSquareRoot();
                    break;
                case "4":
                    CalculatePercentage();
                    break;
                case "5":
                    CalculateArea();
                    break;
                case "6":
                    continueCalculating = false;
                    Console.WriteLine("Thank you for using the calculator!");
                    break;
                default:
                    Console.WriteLine("Invalid choice! Please try again.");
                    break;
            }
        }
    }

    static void PerformBasicArithmetic()
    {
        Console.WriteLine("\n=== Basic Arithmetic ===");
        Console.Write("Enter first number: ");
        if (!double.TryParse(Console.ReadLine(), out double num1))
        {
            Console.WriteLine("Invalid input!");
            return;
        }

        Console.Write("Enter operator (+, -, *, /): ");
        string op = Console.ReadLine();

        Console.Write("Enter second number: ");
        if (!double.TryParse(Console.ReadLine(), out double num2))
        {
            Console.WriteLine("Invalid input!");
            return;
        }

        switch (op)
        {
            case "+":
                Console.WriteLine($"Result: {num1 + num2}");
                break;
            case "-":
                Console.WriteLine($"Result: {num1 - num2}");
                break;
            case "*":
                Console.WriteLine($"Result: {num1 * num2}");
                break;
            case "/":
                if (num2 != 0)
                    Console.WriteLine($"Result: {num1 / num2}");
                else
                    Console.WriteLine("Cannot divide by zero!");
                break;
            default:
                Console.WriteLine("Invalid operator!");
                break;
        }
    }

    static void CalculatePower()
    {
        Console.WriteLine("\n=== Power Calculator ===");
        Console.Write("Enter base number: ");
        if (!double.TryParse(Console.ReadLine(), out double baseNum))
        {
            Console.WriteLine("Invalid input!");
            return;
        }

        Console.Write("Enter exponent: ");
        if (!double.TryParse(Console.ReadLine(), out double exponent))
        {
            Console.WriteLine("Invalid input!");
            return;
        }

        Console.WriteLine($"Result: {Math.Pow(baseNum, exponent)}");
    }

    static void CalculateSquareRoot()
    {
        Console.WriteLine("\n=== Square Root Calculator ===");
        Console.Write("Enter a number: ");
        if (!double.TryParse(Console.ReadLine(), out double num))
        {
            Console.WriteLine("Invalid input!");
            return;
        }

        if (num < 0)
        {
            Console.WriteLine("Cannot calculate square root of a negative number!");
            return;
        }

        Console.WriteLine($"Square root: {Math.Sqrt(num)}");
    }

    static void CalculatePercentage()
    {
        Console.WriteLine("\n=== Percentage Calculator ===");
        Console.Write("Enter the number: ");
        if (!double.TryParse(Console.ReadLine(), out double num))
        {
            Console.WriteLine("Invalid input!");
            return;
        }

        Console.Write("Enter the percentage: ");
        if (!double.TryParse(Console.ReadLine(), out double percentage))
        {
            Console.WriteLine("Invalid input!");
            return;
        }

        double result = (num * percentage) / 100;
        Console.WriteLine($"{percentage}% of {num} is: {result}");
    }

    static void CalculateArea()
    {
        Console.WriteLine("\n=== Area Calculator ===");
        Console.WriteLine("1. Circle");
        Console.WriteLine("2. Rectangle");
        Console.WriteLine("3. Triangle");
        Console.Write("Choose a shape (1-3): ");

        switch (Console.ReadLine())
        {
            case "1":
                Console.Write("Enter radius: ");
                if (double.TryParse(Console.ReadLine(), out double radius))
                    Console.WriteLine($"Area: {Math.PI * radius * radius}");
                else
                    Console.WriteLine("Invalid input!");
                break;

            case "2":
                Console.Write("Enter length: ");
                if (!double.TryParse(Console.ReadLine(), out double length))
                {
                    Console.WriteLine("Invalid input!");
                    return;
                }
                Console.Write("Enter width: ");
                if (!double.TryParse(Console.ReadLine(), out double width))
                {
                    Console.WriteLine("Invalid input!");
                    return;
                }
                Console.WriteLine($"Area: {length * width}");
                break;

            case "3":
                Console.Write("Enter base: ");
                if (!double.TryParse(Console.ReadLine(), out double baseLength))
                {
                    Console.WriteLine("Invalid input!");
                    return;
                }
                Console.Write("Enter height: ");
                if (!double.TryParse(Console.ReadLine(), out double height))
                {
                    Console.WriteLine("Invalid input!");
                    return;
                }
                Console.WriteLine($"Area: {0.5 * baseLength * height}");
                break;

            default:
                Console.WriteLine("Invalid choice!");
                break;
        }
    }
}