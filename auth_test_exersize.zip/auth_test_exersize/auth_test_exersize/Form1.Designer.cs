﻿namespace auth_test_exersize
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            passwordBox = new TextBox();
            loginBox = new TextBox();
            login = new Label();
            password = new Label();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new Point(53, 161);
            button1.Name = "button1";
            button1.Size = new Size(139, 37);
            button1.TabIndex = 0;
            button1.Text = "Войти";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // passwordBox
            // 
            passwordBox.Location = new Point(53, 109);
            passwordBox.Name = "passwordBox";
            passwordBox.PasswordChar = '*';
            passwordBox.Size = new Size(139, 23);
            passwordBox.TabIndex = 1;
            // 
            // loginBox
            // 
            loginBox.Location = new Point(53, 46);
            loginBox.Name = "loginBox";
            loginBox.Size = new Size(139, 23);
            loginBox.TabIndex = 2;
            // 
            // login
            // 
            login.AutoSize = true;
            login.Location = new Point(102, 28);
            login.Name = "login";
            login.Size = new Size(41, 15);
            login.TabIndex = 3;
            login.Text = "Логин";
            // 
            // password
            // 
            password.AutoSize = true;
            password.Location = new Point(102, 91);
            password.Name = "password";
            password.Size = new Size(49, 15);
            password.TabIndex = 4;
            password.Text = "Пароль";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveBorder;
            ClientSize = new Size(246, 233);
            Controls.Add(password);
            Controls.Add(login);
            Controls.Add(loginBox);
            Controls.Add(passwordBox);
            Controls.Add(button1);
            Name = "Form1";
            Text = "Авторизация";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private TextBox passwordBox;
        private TextBox loginBox;
        private Label login;
        private Label password;
    }
}
