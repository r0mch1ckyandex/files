﻿namespace auth_test_exersize
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            quest1Answer = new ComboBox();
            quest1 = new Label();
            quest2 = new Label();
            quest2Answer = new ComboBox();
            quest3 = new Label();
            quest3Answer = new ComboBox();
            quest4 = new Label();
            quest4Answer = new ComboBox();
            quest5 = new Label();
            quest5Answer = new ComboBox();
            button1 = new Button();
            SuspendLayout();
            // 
            // quest1Answer
            // 
            quest1Answer.FormattingEnabled = true;
            quest1Answer.Items.AddRange(new object[] { "Тип данных, отвечающий за целое число", "Проименнованная ячейка памяти с данными", "Процесс повторения одного и того же действия" });
            quest1Answer.Location = new Point(14, 33);
            quest1Answer.Name = "quest1Answer";
            quest1Answer.Size = new Size(269, 23);
            quest1Answer.TabIndex = 0;
            quest1Answer.Text = "Ответ...";
            // 
            // quest1
            // 
            quest1.AutoSize = true;
            quest1.Font = new Font("Segoe UI", 12F);
            quest1.Location = new Point(14, 9);
            quest1.Name = "quest1";
            quest1.Size = new Size(195, 21);
            quest1.TabIndex = 1;
            quest1.Text = "1. Что такое переменная?";
            // 
            // quest2
            // 
            quest2.AutoSize = true;
            quest2.Font = new Font("Segoe UI", 12F);
            quest2.Location = new Point(12, 84);
            quest2.Name = "quest2";
            quest2.Size = new Size(321, 21);
            quest2.TabIndex = 3;
            quest2.Text = "2. Можно ли складывать число со строкой?";
            // 
            // quest2Answer
            // 
            quest2Answer.FormattingEnabled = true;
            quest2Answer.Items.AddRange(new object[] { "Да", "Нет" });
            quest2Answer.Location = new Point(14, 108);
            quest2Answer.Name = "quest2Answer";
            quest2Answer.Size = new Size(269, 23);
            quest2Answer.TabIndex = 2;
            quest2Answer.Text = "Ответ...";
            // 
            // quest3
            // 
            quest3.AutoSize = true;
            quest3.Font = new Font("Segoe UI", 12F);
            quest3.Location = new Point(12, 170);
            quest3.Name = "quest3";
            quest3.Size = new Size(143, 21);
            quest3.TabIndex = 5;
            quest3.Text = "3. Что такое цикл?";
            // 
            // quest3Answer
            // 
            quest3Answer.FormattingEnabled = true;
            quest3Answer.Items.AddRange(new object[] { "Структура, позволяющая повторять один и тот же код несколько раз", "Набор кода, позволяющий вызывать его по опредленному имени", "Именнованя ячейка данных" });
            quest3Answer.Location = new Point(14, 194);
            quest3Answer.Name = "quest3Answer";
            quest3Answer.Size = new Size(269, 23);
            quest3Answer.TabIndex = 4;
            quest3Answer.Text = "Ответ...";
            // 
            // quest4
            // 
            quest4.AutoSize = true;
            quest4.Font = new Font("Segoe UI", 12F);
            quest4.Location = new Point(14, 260);
            quest4.Name = "quest4";
            quest4.Size = new Size(260, 21);
            quest4.TabIndex = 7;
            quest4.Text = "4. В чем разница между float и int?";
            // 
            // quest4Answer
            // 
            quest4Answer.FormattingEnabled = true;
            quest4Answer.Items.AddRange(new object[] { "Они индентичны", "Float - это функция, тогда как Int - тип данных", "Float отвечает за нецелые числа, а Int - за целые" });
            quest4Answer.Location = new Point(14, 284);
            quest4Answer.Name = "quest4Answer";
            quest4Answer.Size = new Size(269, 23);
            quest4Answer.TabIndex = 6;
            quest4Answer.Text = "Ответ...";
            // 
            // quest5
            // 
            quest5.AutoSize = true;
            quest5.Font = new Font("Segoe UI", 12F);
            quest5.Location = new Point(14, 356);
            quest5.Name = "quest5";
            quest5.Size = new Size(276, 21);
            quest5.TabIndex = 9;
            quest5.Text = "5. Соблюдает ли C# принципы ООП?";
            // 
            // quest5Answer
            // 
            quest5Answer.FormattingEnabled = true;
            quest5Answer.Items.AddRange(new object[] { "Нет, C# не ООП язык", "Да, C# является ООП языком" });
            quest5Answer.Location = new Point(14, 380);
            quest5Answer.Name = "quest5Answer";
            quest5Answer.Size = new Size(269, 23);
            quest5Answer.TabIndex = 8;
            quest5Answer.Text = "Ответ...";
            // 
            // button1
            // 
            button1.BackColor = Color.CornflowerBlue;
            button1.Font = new Font("Segoe UI", 14F);
            button1.Location = new Point(14, 427);
            button1.Name = "button1";
            button1.Size = new Size(269, 54);
            button1.TabIndex = 10;
            button1.Text = "Узнать результат!";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(363, 505);
            Controls.Add(button1);
            Controls.Add(quest5);
            Controls.Add(quest5Answer);
            Controls.Add(quest4);
            Controls.Add(quest4Answer);
            Controls.Add(quest3);
            Controls.Add(quest3Answer);
            Controls.Add(quest2);
            Controls.Add(quest2Answer);
            Controls.Add(quest1);
            Controls.Add(quest1Answer);
            Name = "Form2";
            Text = "Тест на знание языков программирования";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ComboBox quest1Answer;
        private Label quest1;
        private Label quest2;
        private ComboBox quest2Answer;
        private Label quest3;
        private ComboBox quest3Answer;
        private Label quest4;
        private ComboBox quest4Answer;
        private Label quest5;
        private ComboBox quest5Answer;
        private Button button1;
    }
}