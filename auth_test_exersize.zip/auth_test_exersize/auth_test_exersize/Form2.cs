﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace auth_test_exersize
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int correctAnswers = 0;
            int wrongAnswers = 0;

            if (quest1Answer.SelectedIndex == 1)
                correctAnswers++;
            else
                wrongAnswers++;

            if (quest2Answer.SelectedIndex == 1)
                correctAnswers++;
            else
                wrongAnswers++;

            if (quest3Answer.SelectedIndex == 0)
                correctAnswers++;
            else
                wrongAnswers++;

            if (quest4Answer.SelectedIndex == 0)
                correctAnswers++;
            else
                wrongAnswers++;

            if (quest5Answer.SelectedIndex == 1)
                correctAnswers++;
            else
                wrongAnswers++;
            MessageBox.Show($"Кол-во правильных ответов: {correctAnswers}, неправильных: {wrongAnswers}");
        }
    }
}
